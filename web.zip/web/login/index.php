<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
<title>login usuario y registro</title>
<link href="css/estilo.css" media="screen" rel="stylesheet">
</head>

<body>
	<div class="container login">
		<div id="login">
			<h1>Login de Usuarios</h1>
		<form name="loginform" id="loginform" action="logins.php" method="POST">
		
			<p>
    	<label for="user_login"> Nombre de Usuario: </br>
    	<input type="text" name="username" id="username" classs="input" size="20" value="" /></label>
    	</p>
		<p>
	<label for="user_pass">Contraseña:</br>
	<input type="password" name="password" id="password" classs="input" size="20" value="" /></label>
	</p>
	
	<p class="submit">
	<input type="submit" name="login"  class="button" value="Entrar" />
	</p>
	
	<p class="regtext"> ¿No estas registrado? <a href="register.php"> Registrate aqui</a>
	</p>
		
		</form>
		</div>
	
	</div>
</body>
</html>