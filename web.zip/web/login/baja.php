<?php
require_once ("includes/conexion.php");
include ("includes/header.php");
session_start();

if (isset($_POST["baja"])){
    if(!empty($_POST['titulo']) && !empty($_POST['anyo']) && !empty($_POST['precio']) && !empty($_POST['fecha_adquisicion'])) {
        $titulo=$_POST['titulo'];
        $anyo=$_POST['anyo'];
        $precio=$_POST['precio'];
        $adquisicion=$_POST['fecha_adquisicion'];
        
        $connection->prepare("delete from libros where TITULO=:titulo ");
        $query->bindParam("titulo",$titulo,PDO::PARAM_STR);
        $query->execute();
        
        if ($query->rowCount() > 0) {
            echo '<p> class="error">El titulo ya esta registrado</p>';
            
        }
        
        if ($query->rowCount() == 0) {
           $query= $connection ->prepare("delete from libros where TITULO=:titulo");
            $query->bindParam("titulo",$titulo, PDO::PARAM_STR);
            $query->bindParam("anyo",$anyo, PDO::PARAM_INT);
            $query->bindParam("precio",$precio, PDO::PARAM_STR);
            $query->bindParam("adquisicion",$adquisicion, PDO::PARAM_DATE);
            $result = $query->execute();
            
            if($result){
                $message = "libro correctamente creado";          
            }
            else {
                $message = "Error al ingresar los datos";
            }
        } //fin de if == 0
    } // fin del if fullname
    
    else {
        $message = "Debe llenar todos los campos";
    }
}// fin del if alta
?>

<?php  if(!empty($message)) {echo "<p class=\"error\">". "Mensaje:  ". $message ."</p>";}?>

<div class="container registro">
	<div id="actualizar">
		 <h1>Borrar Libros</h1>
	<form name="bajaform" id="bajaform" action="baja.php" method="POST">
	<p> 
	<label for="actualizar_pass"> Titulo: </br>
	<input type="text" name="titulo" id="titulo" classs="input" size="32" value="" /></label>
	</p>
	<p>
	
	
		<p class="submit">
	<input type="submit" name="baja" id="baja" class="button" value="Borrar" />
	</p>
	
	<p class="regtext">  <a href="intropage.php">Volver</a>
	</p>
	
	</form>
</div>
</div>
<?php  include("includes/footer.php");?>