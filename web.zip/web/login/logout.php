<?php
session_start();
unset($_SESSION['session_usernma']);
session_destroy();
header("Location: logins.php");
?>