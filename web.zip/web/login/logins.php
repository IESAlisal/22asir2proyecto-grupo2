<?php

require_once ("includes/conexion.php");
include ("includes/header.php");
session_start();

if (isset($_POST['login'])) {
    
    if(!empty($_POST['username']) && !empty($_POST['password'])) {
        $username=$_POST['username'];
        $password=$_POST['password'];
        
        $query = $connection->prepare("SELECT * FROM users WHERE USERNAME=:username");
        $query->bindParam("username", $username, PDO::PARAM_STR);
        $query->execute();
        
        $result=$query->fetch(PDO::FETCH_ASSOC);
        
        if(!$result) {
            echo '<p class="error">La combinacion del Usuario y Contraseña no son validos</p>';
            
        }else {
            if (password_verify($password, $result['password'])) {
                $_SESSION['session_username']=$username;
                header("Location: intropage.php");
            } 
            else {
                $message = "Nombre de usuario o contraseña invalida";
            }
        }
    } //fin del if username
    else {
        $message = "Todos los campos son requeridos";
        
    }
} // fin del if login


?>

<div class="login-content">
	<div class="div">
		<h1>Autenticacion de Usuario</h1>
		<form name="loginform" id="loginform" action="" method="POST">
		<p>
    	<label for="user_login"> Nombre de Usuario: </br>
    	<input type="text" name="username" id="username" classs="input" size="20" value="" /></label>
    	</p>
		<p>
	<label for="user_pass">Contraseña:</br>
	<input type="password" name="password" id="password" classs="input" size="20" value="" /></label>
	</p>
	
	<p class="submit">
	<input type="submit" name="login"  class="button" value="Entrar" />
	</p>
	
	<p class="regtext"> ¿No estas registrado? <a href="register.php"> Registrate aqui</a>
	</p>
		</form>
	</div>

</div>

<?php include("includes/footer.php");?>

<?php if(!empty($message)) {echo "<p class=\"error\">"."MESSAGE: " .$message ."</p>";}?>