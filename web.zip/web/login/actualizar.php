<?php
require_once ("includes/conexion.php");
include ("includes/header.php");
session_start();

if (isset($_POST["actualizar"])){
    if(!empty($_POST['titulo']) && !empty($_POST['precio'])) {
        $titulo=$_POST['titulo'];
        $precio=$_POST['precio'];
    
        
        $consulta = "UPDATE libros SET 'precio'= :precio WHERE 'titulo' = :titulo";
        $sql = $connection->prepare($consulta);
        $sql->bindParam("precio",$precio,PDO::PARAM_STR);
        $sql->execute();
        
        if($sql->rowCount() > 0)
        {
            $count = $sql -> rowCount();
            echo "<div class='content alert alert-primary' >
            Gracias: $count registro ha sido actualizado  </div>";
        }
        else{
            echo "<div class='content alert alert-danger'> No se pudo actulizar el registro  </div>";
            
            print_r($sql->errorInfo());
        }
    
    }
                
    }// fin del if alta
?>

<?php  if(!empty($message)) {echo "<p class=\"error\">". "Mensaje:  ". $message ."</p>";}?>

<div class="container registro">
	<div id="actualizar">
		 <h1>Actualizar Libros</h1>
	<form name="actualizarform" id="actualizarform" action="actualizar.php" method="POST">
	<p> 
	<label for="actualizar_pass"> Titulo: </br>
	<input type="text" name="titulo" id="titulo" classs="input" size="32" value="" /></label>
	</p>
	<p>
	<label for="alta_pass"> Precio: </br>
	<input type="int" name="precio" id="precio" classs="input" size="10" value="" /></label>
	</p>

	
	
	<p class="submit">
	<input type="submit" name="actualizar" id="actualizar" class="button" value="Actualizar" />
	</p>
	
	<p class="regtext">  <a href="intropage.php">Volver</a>
	</p>
	
	</form>
</div>
</div>
<?php  include("includes/footer.php");?>