<?php 
require_once ("includes/conexion.php");
include ("includes/header.php");
session_start();

function getLibros() {
$consulta = "SELECT * FROM libros";
$libros=[];
if ($resultado = $conexion->query($consulta)) {
    while ($libro = $resultado -> fetch_object()) {
        $libros[] = $libro;
    }
    $resultado->close();
    return $libros;
}
}