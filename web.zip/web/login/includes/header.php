<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
<title>login usuario y registro</title>
<link href="css/estilo.css" media="screen" rel="stylesheet">
</head>

<body>