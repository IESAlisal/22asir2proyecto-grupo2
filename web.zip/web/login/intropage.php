<?php
session_start();
if(!isset($_SESSION["session_username"])) {
    header("Location: logins.php");
    
}else {
    include("includes/header.php"); ?>
    <div class="login-content">
    <div class="div"></div>
    <h2>Bienvenido, <span><?php echo $_SESSION['session_username'];?>!</span></h2>
     <p><a href="alta.php">Alta de Libros</a> </p>
      <p><a href="actualizar.php">Actualizar Libros</a> </p>
       <p><a href="baja.php">Baja de Libros</a></p>
    
    
    
    <p><a href="logout.php">Finalice</a> sesion aqui</p>
    </div>
    </div>
    
    <?php include("includes/footer.php");?>
    <?php 
    } //fin del else
    
    ?>
    
