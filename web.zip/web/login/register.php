<?php
require_once ("includes/conexion.php");
include ("includes/header.php");
session_start();

if (isset($_POST["register"])){
    if(!empty($_POST['fullname']) && !empty($_POST['email']) && !empty($_POST['username']) && !empty($_POST['password'])) {
        $full_name=$_POST['fullname'];
        $email=$_POST['email'];
        $username=$_POST['username'];
        $password=$_POST['password'];
        $password_hash= password_hash($password, PASSWORD_BCRYPT);
        
        
        $query = $connection->prepare("select * from users where EMAIL=:email ");
        $query->bindParam("email",$email,PDO::PARAM_STR);
        $query->execute();
        
        if ($query->rowCount() > 0) {
            echo '<p> class="error">El email ya esta registrado</p>';
            
        }
        
        
        if ($query->rowCount() == 0) {
           $query= $connection ->prepare("INSERT INTO users(FULLNAME,USERNAME,PASSWORD,EMAIL) VALUES (:fullname,:username,:password_hash,:email)");
            $query->bindParam("fullname",$full_name, PDO::PARAM_STR);
            $query->bindParam("username",$username, PDO::PARAM_STR);
            $query->bindParam("password_hash",$password_hash, PDO::PARAM_STR);
            $query->bindParam("email",$email, PDO::PARAM_STR);
            $result = $query->execute();
            
            if($result){
                $message = "cuenta correctamente creada";          
            }
            else {
                $message = "Error al ingresar los datos";
            }
        } //fin de if == 0
        else {
            $message = "el nombre de usuario ya existe, ingrese uno nuevo";
        }
    } // fin del if fullname
    
    else {
        $message = "Debe llenar todos los campos";
    }
}// fin del if resgister
?>

<?php  if(!empty($message)) {echo "<p class=\"error\">". "Mensaje:  ". $message ."</p>";}?>

<div class="container registro">
	<div id="login">
		 <h1>Registrate</h1>
	<form name="registrarform" id="registrarform" action="register.php" method="POST">
	<p> 
	<label for="user_login"> Nombre: </br>
	<input type="text" name="fullname" id="fullname" classs="input" size="32" value="" /></label>
	</p>
	<p> 
	<label for="user_pass"> Email: </br>
	<input type="email" name="email" id="email" classs="input" size="32" value="" /></label>
	</p>
	<p>
	<label for="user_pass"> Nombre de Usuario: </br>
	<input type="text" name="username" id="username" classs="input" size="20" value="" /></label>
	</p>
	<p>
	<label for="user_pass"> Contraseña </br>
	<input type="password" name="password" id="password" classs="input" size="32" value="" /></label>
	</p>
	
	
	<p class="submit">
	<input type="submit" name="register" id="register" class="button" value="Registar" />
	</p>
	
	<p class="regtext"> ¿Ya tienes cuenta? <a href="logins.php"> Entra aqui</a>
	</p>
	
	</form>
</div>
</div>
<?php  include("includes/footer.php");?>