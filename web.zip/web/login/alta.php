<?php
require_once ("includes/conexion.php");
include ("includes/header.php");
session_start();

if (isset($_POST["alta"])){
    if(!empty($_POST['titulo']) && !empty($_POST['anyo']) && !empty($_POST['precio']) && !empty($_POST['fecha_adquisicion'])) {
        $titulo=$_POST['titulo'];
        $anyo=$_POST['anyo'];
        $precio=$_POST['precio'];
        $adquisicion=$_POST['fecha_adquisicion'];
        
        $query = $connection->prepare("select * from libros where TITULO=:titulo ");
        $query->bindParam("titulo",$titulo,PDO::PARAM_STR);
        $query->execute();
        
        if ($query->rowCount() > 0) {
            echo '<p> class="error">El titulo ya esta registrado</p>';
            
        }
        
        if ($query->rowCount() == 0) {
           $query= $connection ->prepare("INSERT INTO libros(titulo,anyo,precio,adquisicion) VALUES ('sids',:titulo,:anyo,:precio,:adquisicion)");
            $query->bindParam("titulo",$titulo, PDO::PARAM_STR);
            $query->bindParam("anyo",$anyo, PDO::PARAM_INT);
            $query->bindParam("precio",$precio, PDO::PARAM_STR);
            $query->bindParam("adquisicion",$adquisicion, PDO::PARAM_DATE);
            $result = $query->execute();
            
            if($result){
                $message = "libro correctamente creado";          
            }
            else {
                $message = "Error al ingresar los datos";
            }
        } //fin de if == 0
    } // fin del if fullname
    
    else {
        $message = "Debe llenar todos los campos";
    }
}// fin del if alta
?>

<?php  if(!empty($message)) {echo "<p class=\"error\">". "Mensaje:  ". $message ."</p>";}?>

<div class="container registro">
	<div id="alta">
		 <h1>Ingresar los Libros</h1>
	<form name="altaform" id="altaform" action="alta.php" method="POST">
	<p> 
	<label for="alta_login"> Titulo: </br>
	<input type="text" name="titulo" id="titulo" classs="input" size="32" value="" /></label>
	</p>
	<p> 
	<label for="alta_pass"> Año: </br>
	<input type="year" name="anyo" id="anyo" classs="input" size="32" value="" /></label>
	</p>
	<p>
	<label for="alta_pass"> Precio: </br>
	<input type="decimal" name="precio" id="precio" classs="input" size="10" value="" /></label>
	</p>
	<p>
	<label for="alta_pass"> Fecha de Adquisicion: </br>
	<input type="date" name="adquisicion" id="adquisicion" classs="input" size="32" value="" /></label>
	</p>
	
	
	<p class="submit">
	<input type="submit" name="alta" id="alta" class="button" value="Alta" />
	</p>
	
	
	<p class="regtext">  <a href="libros-guardados.php">Mostrar Libros guardados </a>
	</p>
	<p class="regtext">  <a href="intropage.php">Volver</a>
	</p>
	
	</form>
</div>
</div>
<?php  include("includes/footer.php");?>