-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 23-12-2022 a las 14:44:55
-- Versión del servidor: 10.4.25-MariaDB
-- Versión de PHP: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `libros`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `libros`
--

CREATE TABLE `libros` (
  `num_ejemplar` tinyint(11) NOT NULL,
  `titulo` varchar(30) NOT NULL,
  `anyo` int(11) NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `fecha_adquisicion` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `libros`
--

INSERT INTO `libros` (`num_ejemplar`, `titulo`, `anyo`, `precio`, `fecha_adquisicion`) VALUES
(1, 'harry Potter', 2002, '10.20', '2022-12-22'),
(2, 'harry Potter', 2002, '10.20', '2022-12-22');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `fullname` varchar(25) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `fullname`, `email`, `username`, `password`) VALUES
(1, 'melanie fernandez', 'mfernandezc52@educantabria.es', 'mfernandez', 'Monitor?2'),
(2, 'melanie fernandez', 'mfernandezc52@educantabria.es', 'mfernandez', 'Monitor?2'),
(3, 'alison', 'ali234@educantabria.es', 'alison', '$2y$10$sbm0Oj91xIrpdH35X1eM.uh6q940JAIQUgguWp3j3Y/4rElg5AFHG'),
(4, 'manuel', 'manugra@educantabria.es', 'mfanu23', '$2y$10$maPzw9oIgcYOmqejZN2i/.NgNh0f6wXuc9Zp6MJtRG7oJH8wNZG4e'),
(5, 'ana', 'ana@educantabria.es', 'anita', '$2y$10$0F52nAO0.YKIDsYVEo6Jt.7cx0Pg76WhsNP0xCfOzEd/Qr3g8EeEe'),
(6, 'vielka', 'vivi@gmail.com', 'mfernandez', '$2y$10$i.bZqeE4iAtjk41tyx1Ntu/QP0aRfQw03y.Ocfl2/2qLwv3TbBtvi');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `libros`
--
ALTER TABLE `libros`
  ADD PRIMARY KEY (`num_ejemplar`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `libros`
--
ALTER TABLE `libros`
  MODIFY `num_ejemplar` tinyint(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
